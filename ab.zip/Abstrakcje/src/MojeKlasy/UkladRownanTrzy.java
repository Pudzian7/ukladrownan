package MojeKlasy;

public class UkladRownanTrzy extends UkladRownan {

    public UkladRownanTrzy(double[][] wspolczynniki, double[] wyrazyWolne) {
        super(wspolczynniki, wyrazyWolne);
    }

    @Override
    public double ObliczWyznacznik(int nrKolumny) {
        double[][] macierz = new double[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (nrKolumny == j) {
                    macierz[i][j] = wyrazyWolne[i];
                } else {
                    macierz[i][j] = wspolczynniki[i][j];
                }
            }
        }
        return macierz[0][0] * macierz[1][1] * macierz[2][2]
                + macierz[0][1] * macierz[1][2] * macierz[2][0]
                + macierz[0][2] * macierz[1][0] * macierz[2][1]
                - macierz[0][2] * macierz[1][1] * macierz[2][0]
                - macierz[0][1] * macierz[1][0] * macierz[2][2]
                - macierz[0][0] * macierz[1][2] * macierz[2][1];
    }
    @Override
    public double ObliczNiewiadoma(int nrKolumny) {
        if (nrKolumny == 0) {
            double wyznacznikX = ObliczWyznacznik(0);
            double wyznacznikX1 = ObliczWyznacznik(-1);
            return wyznacznikX / wyznacznikX1;
        } else if (nrKolumny == 1) {
            double wyznacznikY = ObliczWyznacznik(1);
            double wyznacznikY1 = ObliczWyznacznik(-1);
            return wyznacznikY / wyznacznikY1;
        } else if (nrKolumny == 2) {
            double wyznacznikZ = ObliczWyznacznik(2);
            double wyznacznikZ1 = ObliczWyznacznik(-1);
            return wyznacznikZ / wyznacznikZ1;
        } else {
            throw new IllegalArgumentException("Niepoprawny numer kolumny");
        }
    }

    @Override
    public boolean CzyOznaczony() {
        double wyznacznik = ObliczWyznacznik(-1);
        return wyznacznik != 0;
    }
}
