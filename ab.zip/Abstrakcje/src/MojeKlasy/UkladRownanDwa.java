package MojeKlasy;

public class UkladRownanDwa extends UkladRownan {
    public UkladRownanDwa(double[][] wspolczynniki, double[] wyrazyWolne) {
        super(wspolczynniki, wyrazyWolne);
    }

    @Override
    public double ObliczWyznacznik(int nrKolumny) {
        if (nrKolumny == -1) {
            return (wspolczynniki[0][0] * wspolczynniki[1][1]) - (wspolczynniki[0][1] * wspolczynniki[1][0]);
        } else if (nrKolumny == 0 || nrKolumny == 1) {
            double[][] macierz = new double[2][2];
            for (int i = 0; i < 2; i++) {
                if (i == 0) {
                    macierz[i][0] = wyrazyWolne[0];
                    macierz[i][1] = wspolczynniki[0][1];
                } else {
                    macierz[i][0] = wyrazyWolne[1];
                    macierz[i][1] = wspolczynniki[1][1];
                }
            }
            return (macierz[0][0] * macierz[1][1]) - (macierz[0][1] * macierz[1][0]);
        } else {
            throw new IllegalArgumentException("Niepoprawny numer kolumny");
        }
    }
    @Override
    public double ObliczNiewiadoma(int nrKolumny) {
        if (nrKolumny == 0) {
            double wyznacznikX = ObliczWyznacznik(0);
            double wyznacznikX1 = ObliczWyznacznik(-1);
            return wyznacznikX / wyznacznikX1;
        } else if (nrKolumny == 1) {
            double wyznacznikY = ObliczWyznacznik(1);
            double wyznacznikY1 = ObliczWyznacznik(-1);
            return wyznacznikY / wyznacznikY1;
        } else {
            throw new IllegalArgumentException("Niepoprawny numer kolumny");
        }
    }
}




