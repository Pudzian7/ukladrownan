package MojeKlasy;

public class Ostroslup {
    int ilosc_krawedzi_podstawy;

    public Ostroslup(int ilosc_krawedzi_podstawy) {
        this.ilosc_krawedzi_podstawy = ilosc_krawedzi_podstawy;
    }

    public void WypiszPodstawe() {
        String nazwa_figury;
        switch (ilosc_krawedzi_podstawy) {
            case 3:
                nazwa_figury = "trójkąt";
                break;
            case 4:
                nazwa_figury = "czworokąt";
                break;
            case 5:
                nazwa_figury = "pięciokąt";
                break;
            case 6:
                nazwa_figury = "sześciokąt";
                break;
            default:
                nazwa_figury = "wielokąt";
                break;
        }
        System.out.println("Podstawa ostrosłupa to " + nazwa_figury);
    }

    public int WypiszScianyBoczne() {
        int ilosc_scian_bocznych = ilosc_krawedzi_podstawy;
        System.out.println("Ilość ścian bocznych to: " + ilosc_scian_bocznych);
        return ilosc_scian_bocznych;
    }
}
