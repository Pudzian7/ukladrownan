package MojeKlasy;


public abstract class UkladRownan {
    protected double[][] wspolczynniki;
    protected double[] wyrazyWolne;

    public UkladRownan(double[][] wspolczynniki, double[] wyrazyWolne) {
        this.wspolczynniki = wspolczynniki;
        this.wyrazyWolne = wyrazyWolne;
    }

    public abstract double ObliczWyznacznik(int nrKolumny);

    public abstract double ObliczNiewiadoma(int nrKolumny);

    public boolean CzyOznaczony() {
        double wyznacznik = ObliczWyznacznik(-1);
        for (int i = 0; i < wspolczynniki.length; i++) {
            double wyznacznikKolumny = ObliczWyznacznik(i);
            if (wyznacznikKolumny != 0 && wyznacznik != 0) {
                return true;
            }
        }
        return false;
    }
}