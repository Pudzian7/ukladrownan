import MojeKlasy.Ostroslup;
import MojeKlasy.UkladRownan;
import MojeKlasy.UkladRownanDwa;
import MojeKlasy.UkladRownanTrzy;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Ostroslup ostroslupTrojkatny = new Ostroslup(3);
        Ostroslup ostroslupPieciokatny = new Ostroslup(5);
        Ostroslup ostroslupSzesciokatny = new Ostroslup(6);

        Ostroslup stozek = new Ostroslup(0) {
            @Override
            public void WypiszPodstawe() {
                System.out.println("Podstawa stożka to koło");
            }

            @Override
            public int WypiszScianyBoczne() {
                int ilosc_scian_bocznych = 1;
                System.out.println("Stożek ma ścian bocznych: " + ilosc_scian_bocznych);
                return ilosc_scian_bocznych;
            }
        };

        ostroslupTrojkatny.WypiszPodstawe();
        int ilosc_scian_ostroslupa_trojkatnego = ostroslupTrojkatny.WypiszScianyBoczne();

        ostroslupPieciokatny.WypiszPodstawe();
        int ilosc_scian_ostroslupa_pieciokatnego = ostroslupPieciokatny.WypiszScianyBoczne();

        ostroslupSzesciokatny.WypiszPodstawe();
        int ilosc_scian_ostroslupa_szesciokątnego = ostroslupSzesciokatny.WypiszScianyBoczne();
        stozek.WypiszPodstawe();
        int ilosc_scian_stozka = stozek.WypiszScianyBoczne();

        //uklad


        double[][] wspolczynnikiDwa = {{1, 1}, {-1, 3}};
        double[] wyrazyWolneDwa = {3, 5};
        UkladRownanDwa ukladDwa = new UkladRownanDwa(wspolczynnikiDwa, wyrazyWolneDwa);

        double[][] wspolczynnikiTrzy = {{1, 2, 1}, {2, -1, 2}, {3, 1, -1}};
        double[] wyrazyWolneTrzy = {3, 6, 1};
        UkladRownanTrzy ukladTrzy = new UkladRownanTrzy(wspolczynnikiTrzy, wyrazyWolneTrzy);


        System.out.println("Rozwiązanie układu równań z dwiema niewiadomymi:");
        System.out.println("Współczynniki:");
        for (double[] row : wspolczynnikiDwa) {
            System.out.println(Arrays.toString(row));
        }
        System.out.println("Wyrazy wolne:");
        System.out.println(Arrays.toString(wyrazyWolneDwa));
        if (ukladDwa.CzyOznaczony()) {
            double x = ukladDwa.ObliczNiewiadoma(0);
            double y = ukladDwa.ObliczNiewiadoma(1);
            System.out.println("x = " + x);
            System.out.println("y = " + y);
        } else {
            System.out.println("Układ równań nieoznaczony lub sprzeczny");
        }


        System.out.println("Rozwiązanie układu równań z trzema niewiadomymi:");
        System.out.println("Współczynniki:");
        for (double[] row : wspolczynnikiTrzy) {
            System.out.println(Arrays.toString(row));
        }
        System.out.println("Wyrazy wolne:");
        System.out.println(Arrays.toString(wyrazyWolneTrzy));
        if (ukladTrzy.CzyOznaczony()) {
            double x = ukladTrzy.ObliczNiewiadoma(0);
            double y = ukladTrzy.ObliczNiewiadoma(1);
            double z = ukladTrzy.ObliczNiewiadoma(2);
            System.out.println("x = " + x);
            System.out.println("y = " + y);
            System.out.println("z = " + z);
        } else {
            System.out.println("Układ równań nieoznaczony lub sprzeczny");
        }
    }
    }



